<?php
/* @var $this yii\web\View */

use app\services\PostService;

$this->title = 'Kết quả nhanh';
$Config = Yii::$app->params;
$Url_Media = $Config['media'];
$Service = new PostService();
?>
<div id="box_panel1" class="container">
    <div class="row">
        <div class="col-md-10">
            <div class="row">
                <div class="col-md-8">
                    <div class="row">

                        <div class="item-one">
                            <?php
                            if (count($Data_Hot > 0)) {
                                $img_hot = json_decode($Data_Hot[0]['Thumb'], true);
                                ?>
                                <div class="col-md-4">
                                    <h3 class="name-post"><a href="<?= $Service->makeUrl($Data_Hot[0]) ?>"><?= $Data_Hot[0]['Title'] ?></a></h3>
                                    <p class="text-justify"><?= $Service->subStringv($Data_Hot[0]['Summary'], 200) ?></p>
                                    <ul class="list-tags">
                                        <li><a href="#">Liverpool</a></li>
                                        <li><a href="#">Chelsea</a></li>
                                    </ul>
                                </div>
                                <div class="col-md-8">
                                    <div class="img">
                                        <a href="<?= $Service->makeUrl($Data_Hot[0]) ?>"><img src="<?= $Url_Media . $img_hot['size1'] ?>"/></a>
                                    </div>
                                </div>
                                <?php
                            }
                            unset($Data_Hot[0]);
                            foreach ($Data_Hot as $key_hot => $value_hot) {
                                ?>
                                <div class="col-md-4 item-box-one">
                                    <h3><a href="<?= $Service->makeUrl($value_hot) ?>"><?= $value_hot['Title'] ?></a></h3>
                                </div>
                            <?php } ?>

                            <div class="col-md-12 box-adv adv1">
                                <a href="#"><img src="images/adv1.jpg" /></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 box-ltd">
                    <table class="table-ltd1">
                        <tbody>
                            <tr>
                                <td class="icf">
                                    <img src="images/ic1.png" />
                                    17/8
                                </td>
                                <td class="team">Manchester United</td>
                                <td class="time">04:00</td>
                                <td class="team">Chelsea</td>
                                <td class="btn-cm"><a href="#">Bình luận</a></td>
                            </tr>
                            <tr>
                                <td class="icf">
                                    <img src="images/ic1.png" />
                                    17/8
                                </td>
                                <td class="team">Bayern Munich</td>
                                <td class="time">04:00</td>
                                <td class="team">Chelsea</td>
                                <td class="btn-cm"><a href="#">Bình luận</a></td>
                            </tr>
                            <tr>
                                <td class="icf">
                                    <img src="images/ic1.png" />
                                    17/8
                                </td>
                                <td class="team">Bayern Munich</td>
                                <td class="time">04:00</td>
                                <td class="team">Manchester United</td>
                                <td class="btn-cm live"><i class="fa fa-video-camera" aria-hidden="true"></i> <a href="#">Live</a></td>
                            </tr>
                            <tr>
                                <td class="icf">
                                    <img src="images/ic1.png" />
                                    17/8
                                </td>
                                <td class="team">Manchester United</td>
                                <td class="time">04:00</td>
                                <td class="team">Chelsea</td>
                                <td class="btn-cm"><a href="#">Bình luận</a></td>
                            </tr>
                            <tr>
                                <td class="icf">
                                    <img src="images/ic1.png" />
                                    17/8
                                </td>
                                <td class="team">Manchester United</td>
                                <td class="time">04:00</td>
                                <td class="team">Chelsea</td>
                                <td class="btn-cm"><a href="#">Bình luận</a></td>
                            </tr>
                            <tr>
                                <td class="icf">
                                    <img src="images/ic1.png" />
                                    17/8
                                </td>
                                <td class="team">Manchester United</td>
                                <td class="time">04:00</td>
                                <td class="team">Chelsea</td>
                                <td class="btn-cm"><a href="#">Bình luận</a></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="box-adv adv2">
                        <a href="#"><img src="images/adv2.jpg"/></a>
                    </div>
                    <div class="box-adv adv3">
                        <a href="#"><img src="images/adv3.jpg"/></a>
                    </div>
                </div>

                <div class="col-md-8 box-feature">
                    <div class="row">
                        <div class="col-md-12 title_box">
                            <div class="content_title_box">
                                <span>Tin nổi bật</span>
                            </div>
                        </div>



                        <div class="exTab1">	
                            <div class="col-md-12">
                                <ul class="nav nav-pills">
                                    <li class="active">
                                        <a  href="#1a" data-toggle="tab">Trong nước</a>
                                    </li>
                                    <li>
                                        <a href="#2a" data-toggle="tab">Quốc tế</a>
                                    </li>

                                </ul>
                            </div>
                            <div class="clear"></div>
                            <div class="tab-content clearfix">
                                <div class="tab-pane active" id="1a">
                                    <?php
                                    foreach ($Data_Feature as $key_f => $value_f) {
                                        $Img_F = json_decode($value_f['Thumb'], true);
                                        ?>
                                        <div class="col-md-6 item-feature">
                                            <div class="content-item">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <a href="<?= $Service->makeUrl($value_f) ?>"><img src="<?= $Url_Media . $Img_F['size0'] ?>"/></a>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <h3><a href="<?= $Service->makeUrl($value_f) ?>"><?= $value_f['Title'] ?></a></h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div>										
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 box-new">
                    <div class="row">
                        <div class="col-md-12 title_box">
                            <div class="content_title_box">
                                <span>Tin mới nhất</span>
                            </div>
                        </div>

                        <div class="exTab1">	
                            <div class="col-md-12">
                                <ul class="nav nav-pills">
                                    <li class="active">
                                        <a  href="#1a" data-toggle="tab">Tất cả</a>
                                    </li>
                                    <li>
                                        <a  href="#1a" data-toggle="tab">Trong nước</a>
                                    </li>
                                    <li>
                                        <a href="#2a" data-toggle="tab">Quốc tế</a>
                                    </li>

                                </ul>
                            </div>
                            <div class="clear"></div>
                            <div class="tab-content clearfix">
                                <div class="tab-pane active" id="1a">
                                    <?php
                                    foreach ($Data_New as $key_n => $value_n) {
                                        ?>
                                        <div class="col-md-12 item-new">
                                            <div class="content-item">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <span><?= date('H:i', strtotime($value_n['DateCreate'])) ?></span>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <h3><a href="<?= $Service->makeUrl($value_n) ?>"><?= $value_n['Title'] ?></a></h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div>										
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="box-adv adv-4">
                <a href="#"><img src="images/adv4.jpg"/></a>
            </div>
            <div class="box-adv adv-5" style="margin-top:30px;">
                <a href="#"><img src="images/adv6.jpg"/></a>
            </div>
        </div>
    </div>

</div> 


<?php
foreach ($Categories_Home_Big['data'] as $key_big => $value_big) {
    ?>
    <div class="box-panel2 container">
        <div class="row">
            <div class="col-md-12">
                <div class="title_box_panel2">
                    <div class="content-title">
                        <a href="<?= $Service->makeUrl_Categoies($value_big) ?>"><img src="<?= $Url_Media . $value_big['Icon'] ?>"/></a>
                        <h3><a href="<?= $Service->makeUrl_Categoies($value_big) ?>"><?= $value_big['Title'] ?></a></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-12 menu-box-title">
                <ul class="pull-right">
                    <li><a href="#">Các giải đấu</a></li>
                    <li><a href="#">Lịch thi đấu</a></li>
                    <li><a href="#">Kết quả</a></li>
                    <li><a href="#">Trực tiếp bóng đá Anh</a></li>
                </ul>
            </div>

            <div class="col-md-3">
                <div class="title-tieudiem">
                    <img src="images/ic-td.png"/>
                    <span>Tin tiêu điểm</span>
                </div>
                <?php
                $Data_Tieu_Diem_Big = $value_big['Tin_tieu_diem'][0];
                if (count($Data_Tieu_Diem_Big) > 0) {
                    $Img_Tieu_Diem_Big = json_decode($Data_Tieu_Diem_Big[0]['Thumb'], true);
                    ?>
                    <div class="item-td">
                        <div class="row">
                            <div class="col-md-12">
                                <h3><a href="<?= $Service->makeUrl($Data_Tieu_Diem_Big[0]) ?>"><?= $Data_Tieu_Diem_Big[0]['Title'] ?></a></h3>
                            </div>
                            <div class="col-md-5">
                                <a href="<?= $Service->makeUrl($Data_Tieu_Diem_Big[0]) ?>"><img src="<?= $Url_Media . $Img_Tieu_Diem_Big['size1'] ?>"/></a>
                            </div>
                            <div class="col-md-7">
                                <p><?= $Service->subStringv($Data_Tieu_Diem_Big[0]['Summary'], 100) ?></p>
                            </div>

                            <div class="col-md-12">
                                <ul class="list-tag2">
                                    <li><a href="#">Liverpool</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php } ?>

                <div class="title-chuyen-nhuong">
                    <img src="images/ic-ch.png"/>
                    <span>Tin chuyển nhượng</span>
                </div>
                <div class="item-chuyen-nhuong">
                    <ul>
                        <?php
                        if(count($value_big['Tin_chuyen_nhuong'][0])>0){
                        foreach ($value_big['Tin_chuyen_nhuong'][0] as $key_ch_big => $value_ch_big) { ?>
                            <li><a href="<?= $Service->makeUrl($value_ch_big); ?>"><?= $value_ch_big['Title'] ?></a></li>
                        <?php }} ?>
                    </ul>
                </div>
                <div class="col-md-12 read-more">
                    <a class="pull-right" href="#">Xem tất cả</a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12">
                        <div class="menu-box-center">
                            <ul>
                                <li class="active"><a href="<?= $Service->makeUrl_Categoies($value_big) ?>">Tổng hợp</a></li>
                                <?php
                                foreach ($value_big['Sub_categories'][0] as $key_sub_big => $value_sub_big) {
                                    if (strpos($value_sub_big['Title'], 'chuyển nhượng') == false) {
                                        ?>
                                        <li><a href="<?= $Service->makeUrl_Categoies($value_sub_big) ?>"><?= $value_sub_big['Title'] ?></a></li>
                                        <?php
                                    }
                                }
                                ?>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <?php
                        $Data_Post_Big = $value_big['ListPost'][0];
                        if (count($Data_Post_Big) > 0) {
                            $Img_Post_B = json_decode($Data_Post_Big[0]['Thumb'], true);
                            ?>
                            <div class="content-center">
                                <div class="row">
                                    <div class="col-md-5">
                                        <a href="<?= $Service->makeUrl($Data_Post_Big[0]); ?>">
                                            <img class="img-box-center" src="<?= $Url_Media . $Img_Post_B['size1'] ?>" />
                                        </a>
                                    </div>
                                    <div class="col-md-7">
                                        <div class="caption-box">
                                            <h3><a href="<?= $Service->makeUrl($Data_Post_Big[0]); ?>"><?= $Data_Post_Big[0]['Title'] ?></a></h3>
                                            <p><?= $Service->subStringv($Data_Post_Big[0]['Summary'], 200) ?></p>
                                        </div>
                                        <ul class="list-tag2">
                                            <li><a href="#">Liverpool</a></li>
                                            <li><a href="#">Chelsea</a></li>
                                        </ul>
                                    </div>		

                                </div>

                            </div>
                            <?php
                            unset($Data_Post_Big[0]);
                        }
                        ?>

                        <div class="row">
                            <?php foreach ($Data_Post_Big as $key_post_big => $value_post_big) { ?>
                                <div class="col-md-6 item-box-center">
                                    <h3><a href="<?= $Service->makeUrl($value_post_big) ?>"><?= $value_post_big['Title'] ?></a></h3>
                                </div>
                            <?php } ?>

                            <div class="col-md-12 read-more">
                                <a class="pull-right" href="<?= $Service->makeUrl_Categoies($value_big) ?>">Xem tất cả</a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-md-3">
                <ul class="title-box-bxh">
                    <li><a href="#">Bxh</a></li>
                    <li><a href="#">Ltđ</a></li>
                </ul>

                <table class="bxh-ltd">
                    <tbody>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>

                    </tbody>
                </table>
                <div class="col-sm-12 text-center more-bxh">
                    <a href="#">Xem thêm <img src="images/more.png"/></a>
                </div>
            </div>

            <div class="col-md-12">
                <div class="content-box-video">
                    <div  class="row">
                        <div class="col-md-12 title-box-video">
                            <img src="images/ic-vd.png"/> Video bóng đá anh
                        </div>

                        <div class="col-md-3 itemm-box-video">
                            <div class="img-vd">
                                <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                <a href="#"><img src="images/a4.jpg"/></a>
                            </div>
                            <div class="caption-video">
                                <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                <p>(ICC 2017)</p>
                            </div>
                        </div>
                        <div class="col-md-3 itemm-box-video">
                            <div class="img-vd">
                                <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                <a href="#"><img src="images/a5.jpg"/></a>
                            </div>
                            <div class="caption-video">
                                <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                <p>(ICC 2017)</p>
                            </div>
                        </div>
                        <div class="col-md-3 itemm-box-video">
                            <div class="img-vd">
                                <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                <a href="#"><img src="images/a6.jpg"/></a>
                            </div>
                            <div class="caption-video">
                                <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                <p>(ICC 2017)</p>
                            </div>
                        </div>
                        <div class="col-md-3 itemm-box-video">
                            <div class="img-vd">
                                <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                <a href="#"><img src="images/a7.jpg"/></a>
                            </div>
                            <div class="caption-video">
                                <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                <p>(ICC 2017)</p>
                            </div>
                        </div>
                    </div>
                </div>	
            </div>
        </div>
    </div>
<?php } ?>


<?php
foreach ($Categories_Home_Rank['data'] as $key_r => $value_r) {
    ?>

    <div class="box-panel3 container">
        <div class="row">
            <div class="col-md-12">
                <div class="title_box_panel2">
                    <div class="content-title">
                        <a href="<?= $Service->makeUrl_Categoies($value_r) ?>"><img src="<?= $Url_Media . $value_r['Icon'] ?>"/></a>
                        <h3><a href="<?= $Service->makeUrl_Categoies($value_r) ?>"><?= $value_r['Title'] ?></a></h3>
                       <!-- <span> / </span>
                        <a href="#"> <img src="images/ic-f1.png"/></a>
                        <h3 class="last"><a href="#">Bóng đá Châu Âu</a></h3>-->
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-4">
                        <div class="title-tieudiem">
                            <img src="images/ic-td.png"/>
                            <span>Tin tiêu điểm</span>
                        </div>

                        <div class="item-td">
                            <div class="row">
                                <?php
                                $Data_Tieu_Diem = $value_r['Tin_tieu_diem'][0];
                                if (count($Data_Tieu_Diem) > 0) {
                                    $Img_r = json_decode($Data_Tieu_Diem[0]['Thumb'], true);
                                    ?>
                                    <div class="col-md-12">
                                        <h3><a href="<?= $Service->makeUrl($Data_Tieu_Diem[0]) ?>"><?= $Data_Tieu_Diem[0]['Title'] ?></a></h3>
                                    </div>
                                    <div class="col-md-5">
                                        <a href="<?= $Service->makeUrl($Data_Tieu_Diem[0]) ?>"><img src="<?= $Url_Media . $Img_r['size1'] ?>"/></a>
                                    </div>
                                    <div class="col-md-7">
                                        <p><?= $Service->subStringv($Data_Tieu_Diem[0]['Summary'], 100) ?></p>
                                    </div>
                                    <div class="col-md-12">
                                        <ul class="list-tag2">
                                            <li><a href="#">Liverpool</a></li>
                                        </ul>

                                    </div>
                                    <?php
                                    unset($Data_Tieu_Diem[0]);
                                }
                                ?>

                                <div class="col-md-12">

                                    <div class="item-chuyen-nhuong">
                                        <ul>
                                            <?php foreach ($Data_Tieu_Diem as $key_r_td => $value_r_td) { ?>
                                                <li><a href="<?= $Service->makeUrl($value_r_td) ?>"><?= $value_r_td['Title'] ?></a></li>
                                            <?php } ?>

                                        </ul>
                                    </div>
                                </div>


                            </div>
                        </div>



                    </div>
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="menu-box-center">
                                    <ul>
                                        <li class="active"><a href="<?= $Service->makeUrl_Categoies($value_r) ?>">Tổng hợp</a></li>
                                        <?php
                                        $List_Sub_Categories_r = $value_r['Sub_categories'][0];
                                        foreach ($List_Sub_Categories_r as $key_sub_cat_r => $value_sub_cat_r) {
                                            if (strpos($value_sub_cat_r['Title'], 'chuyển nhượng') == false) {
                                                ?>
                                                <li><a href="<?= $Service->makeUrl_Categoies($value_sub_cat_r); ?>"><?= $value_sub_cat_r['Title'] ?></a></li>
                                                <?php
                                            }
                                        }
                                        ?>

                                    </ul>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <?php
                                $Data_Post_Td = $value_r['ListPost'][0];
                                if (count($Data_Post_Td) > 0) {
                                    $Img_P = json_decode($Data_Post_Td[0]['Thumb'], true);
                                    ?>
                                    <div class="content-center">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <a href="<?= $Service->makeUrl($Data_Post_Td[0]); ?>">
                                                    <img class="img-box-center" src="images/a3.jpg" />
                                                </a>
                                            </div>
                                            <div class="col-md-7">
                                                <div class="caption-box">
                                                    <h3><a href="<?= $Service->makeUrl($Data_Post_Td[0]); ?>"><?= $Data_Post_Td[0]['Title'] ?></a></h3>
                                                    <p><?= $Service->subStringv($Data_Post_Td[0]['Summary'], 200) ?></p>
                                                </div>
                                                <ul class="list-tag2">
                                                    <li><a href="#">Liverpool</a></li>
                                                    <li><a href="#">Chelsea</a></li>
                                                </ul>
                                            </div>		

                                        </div>

                                    </div>
                                    <?php
                                    unset($Data_Post_Td[0]);
                                }
                                ?>

                                <div class="row">
                                    <?php foreach ($Data_Post_Td as $key_p_r => $value_p_r) { ?>
                                        <div class="col-md-6 item-box-center">
                                            <h3><a href="<?= $Service->makeUrl($value_p_r); ?>"><?= $value_p_r['Title'] ?></a></h3>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="content-box-video">
                            <div  class="row">
                                <div class="col-md-12 title-box-video">
                                    <img src="images/ic-vd.png"/> Video bóng đá thế giới
                                </div>

                                <div class="col-md-3 itemm-box-video">
                                    <div class="img-vd">
                                        <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                        <a href="#"><img src="images/a4.jpg"/></a>
                                    </div>
                                    <div class="caption-video">
                                        <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                        <p>(ICC 2017)</p>
                                    </div>
                                </div>
                                <div class="col-md-3 itemm-box-video">
                                    <div class="img-vd">
                                        <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                        <a href="#"><img src="images/a5.jpg"/></a>
                                    </div>
                                    <div class="caption-video">
                                        <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                        <p>(ICC 2017)</p>
                                    </div>
                                </div>
                                <div class="col-md-3 itemm-box-video">
                                    <div class="img-vd">
                                        <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                        <a href="#"><img src="images/a6.jpg"/></a>
                                    </div>
                                    <div class="caption-video">
                                        <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                        <p>(ICC 2017)</p>
                                    </div>
                                </div>
                                <div class="col-md-3 itemm-box-video">
                                    <div class="img-vd">
                                        <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                        <a href="#"><img src="images/a7.jpg"/></a>
                                    </div>
                                    <div class="caption-video">
                                        <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                        <p>(ICC 2017)</p>
                                    </div>
                                </div>
                            </div>
                        </div>	
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <ul class="title-box-bxh">
                    <li><a href="#">Bxh</a></li>
                    <li><a href="#">Ltđ</a></li>
                </ul>

                <table class="bxh-ltd">
                    <tbody>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>
                        <tr>
                            <td class="stt">1</td>
                            <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="point">93</td>
                        </tr>

                    </tbody>
                </table>
                <div class="col-sm-12 text-center more-bxh">
                    <a href="#">Xem thêm <img src="images/more.png"/></a>
                </div>
            </div>


        </div>
    </div>
<?php } ?>

<div class="box-panel4 container">
    <div class="row">
        <?php
        foreach ($Categories_Home_Sm['data'] as $key_c_sm => $value_c_sm) {
            $Data_Post_C_Sm = $value_c_sm['ListPost'][0];
            if ($key_c_sm == 0 || $key_c_sm == 2) {
                ?>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-12 title-box-4">
                            <div class="content-title">
                                <a href="<?= $Service->makeUrl_Categoies($value_c_sm) ?>">
                                    <img src="<?= $Url_Media . $value_c_sm['Icon'] ?>"/> <?= $value_c_sm['Title'] ?>
                                </a>
                            </div>
                        </div>
                        <?php
                        if (count($Data_Post_C_Sm > 0)) {
                            $Img_C_Sm = json_decode($Data_Post_C_Sm[0]['Thumb'], true);
                            ?>
                            <div class="col-md-12 item-box-4">
                                <div class="img">
                                    <a href="<?= $Service->makeUrl($Data_Post_C_Sm[0]) ?>">
                                        <img src="<?= $Url_Media . $Img_C_Sm['size1'] ?>"/>
                                    </a>

                                </div>
                                <h3><a href="<?= $Service->makeUrl($Data_Post_C_Sm[0]) ?>"><?= $Data_Post_C_Sm[0]['Title'] ?></a></h3>
                            </div>
                            <?php
                        }
                        unset($Data_Post_C_Sm[0]);
                        ?>

                        <div class="col-md-12">
                            <ul class="list-item">
                                <?php foreach ($Data_Post_C_Sm as $key_p_sm => $value_p_sm) { ?>
                                    <li><a href="<?= $Service->makeUrl($value_p_sm) ?>"><?= $value_p_sm['Title'] ?></a></li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php } else { ?>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-12 title-box-4">
                            <div class="content-title">
                                <a href="<?= $Service->makeUrl_Categoies($value_c_sm) ?>">
                                    <img src="<?= $Url_Media . $value_c_sm['Icon'] ?>"/> <?= $value_c_sm['Title'] ?>
                                </a>
                            </div>
                        </div>


                        <?php
                        foreach ($Data_Post_C_Sm as $key_p_sm => $value_p_sm) {
                            $Img_Post_Sm = json_decode($value_p_sm['Thumb'], true);
                            ?>

                            <div class="col-md-12 item-center">
                                <div class="content-box-center">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="img">
                                                <a href="<?= $Service->makeUrl($value_p_sm) ?>"><img src="<?= $Url_Media . $Img_Post_Sm['size0'] ?>"></a>
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="caption-center">
                                                <h3><a href="<?= $Service->makeUrl($value_p_sm) ?>"><?= $value_p_sm['Title'] ?></a></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>



                    </div>
                </div>

                <?php
            }
        }
        ?>

    </div>
</div>

<div class="box-panel5 container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-box5">
                        <div class="left-title-box5 pull-left">
                            <img src="images/ic-cl.png"/>
                            <span>Lịch thi đấu - Kết quả bóng đá</span>
                        </div>

                        <div class="right-title-box5 pull-right">
                            <ul>
                                <li class="active"><a href="#">Premier League</a></li>
                                <li><a href="#">La Liga</a></li>
                                <li><a href="#">Champions League</a></li>
                                <li><a href="#"> V-League</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="sub-title-box5">
                        <img src="images/lg-p.png"/>
                        <span>LTĐ Premier League  2017 (Vòng 3)</span>
                    </div>
                </div>

                <div class="col-md-2">
                    <table class="tbl-vong-dau">
                        <tbody>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr class="v-f">
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="ltd-kq-box5">
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-mu.png"/> Mancheter United</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-ev.png"/> Southamton</td>
                            <td class="ac"><i class="fa fa-star f-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-mu.png"/> Mancheter United</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-ev.png"/> Southamton</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-mu.png"/> Mancheter United</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-ev.png"/> Southamton</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-mu.png"/> Mancheter United</td>
                            <td class="kq"><strong>0 : 2</strong></td>
                            <td class="t-td-last"><img src="images/logo-ev.png"/> Southamton</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><strong>0 : 0</strong></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-mu.png"/> Mancheter United</td>
                            <td class="kq"><strong>3 : 0</strong></td>
                            <td class="t-td-last"><img src="images/logo-ev.png"/> Southamton</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><strong>3 : 0</strong></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>

                    </table>
                </div>
                <div class="col-md-2">
                    <div class="title-bxh-box5">
                        <span>Bảng xếp hạng</span>
                    </div>
                    <table class="bxh-ltd">
                        <tbody>
                            <tr>
                                <td class="stt">1</td>
                                <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                                <td class="point">93</td>
                            </tr>
                            <tr>
                                <td class="stt">1</td>
                                <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                                <td class="point">93</td>
                            </tr>
                            <tr>
                                <td class="stt">1</td>
                                <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                                <td class="point">93</td>
                            </tr>
                            <tr>
                                <td class="stt">1</td>
                                <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                                <td class="point">93</td>
                            </tr>
                            <tr>
                                <td class="stt">1</td>
                                <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                                <td class="point">93</td>
                            </tr>
                            <tr>
                                <td class="stt">1</td>
                                <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                                <td class="point">93</td>
                            </tr>
                            <tr>
                                <td class="stt">1</td>
                                <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                                <td class="point">93</td>
                            </tr>
                            <tr>
                                <td class="stt">1</td>
                                <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                                <td class="point">93</td>
                            </tr>
                            <tr>
                                <td class="stt">1</td>
                                <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                                <td class="point">93</td>
                            </tr>
                            <tr>
                                <td class="stt">1</td>
                                <td class="team-bxh"><img src="images/logo-chs.png"/> Chelsea</td>
                                <td class="point">93</td>
                            </tr>

                        </tbody>
                    </table>
                </div>
                <div class="col-md-2">
                    <div class="adv">
                        <a href="#"><img style="width:100%" src="images/adv4.jpg" /></a>
                    </div>
                </div>
            </div>
        </div>
