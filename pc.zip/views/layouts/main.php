<?php
/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?= Html::csrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?></title>
        <?php $this->head() ?>
    </head>
    <body>
        <?php $this->beginBody() ?>
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-md-2">
                        <a href="/"><img src="images/logo.png"/></a>
                    </div>
                    <div class="col-md-10">
                        <div class="menu-site">
                            <ul>
                                <li> <a href="#">Tin nóng</a></li>
                                <li> <a href="#">Sea game 29</a></li>
                                <li> <a href="#">Bình luận</a></li>
                                <li> <a href="#">Chuyển nhượng</a></li>
                                <li> <a href="#">Nhận định</a></li>
                                <li> <a href="#">Anh </a></li>
                                <li> <a href="#">Tbn</a></li>
                                <li> <a href="#">Châu âu</a></li>
                                <li> <a href="#">Việt nam</a></li>
                                <li> <a href="#">Video</a></li>
                                <li> <a href="#">Khác</a></li>
                            </ul>
                        </div>
                        <div class="hot-menu">
                            <ul>
                                <li><span>Hot</span></li>
                                <li><a href="#">LTĐ bóng đá nam Sea Game 29</a></li>
                                <li> <a href="#">LTĐ Sea Game 29</a></li>
                                <li> <a href="#">Bảng tổng sắp HC Sea Game 29</a></li>								
                            </ul>
                        </div>

                        <div class="search pull-right">
                            <button class="btn btn-search"><i class="fa fa-search" aria-hidden="true"></i></button>
                            <form class="form-inline pull-left form-search">
                                <div class="form-group">									
                                    <input type="text" class="form-control" id="s" placeholder="Từ khóa tìm kiếm">
                                </div>

                                <button type="submit" class="btn btn-default"><i class="fa fa-search" aria-hidden="true"></i></button>
                            </form>
                        </div>
                    </div>
                </div>	
            </div>
        </header>
        <?= $content;?>

        

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="menu-footer">
                            <ul>
                                <li><a href="#">Trang chủ</a></li>
                                <li><a href="#">Giới thiệu</a></li>
                                <li><a href="#">Điều khoản sử dụng</a></li>
                                <li><a href="#">Chính sách bảo mật</a></li>
                                <li><a href="#">Liên hệ quảng cáo</a></li>
                                <li><a href="#">Đặt làm trang chủ</a></li>
                                <li><a href="#">Site map</a></li>
                                <li><a href="#">RSS</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="content-list-link">
                            <div class="row">
                                <ul class="list-link">
                                    <li class="col-md-2"><a href="#">Clip bóng đá</a></li>
                                    <li class="col-md-2"><a href="#">Kết quả bóng đá</a></li>
                                    <li class="col-md-2"><a href="#">Tin nóng </a></li>
                                    <li class="col-md-2"><a href="#">Clip vui</a></li>
                                    <li class="col-md-2"><a href="#">Bình luận </a></li>
                                    <li class="col-md-2"><a href="#">Chuyển nhượng</a></li>
                                    <li class="col-md-2"><a href="#">Bóng đá Anh</a></li>
                                    <li class="col-md-2"><a href="#">Bóng đá Tây Ban Nha</a></li>
                                    <li class="col-md-2"><a href="#">Bóng đá châu Âu </a></li>
                                    <li class="col-md-2"><a href="#">Bóng đá Italia</a></li>
                                    <li class="col-md-2"><a href="#">Hậu trường </a></li>
                                    <li class="col-md-2"><a href="#">Bóng dá Việt Nam</a></li>
                                    <li class="col-md-2"><a href="#">Bóng đá Đức</a></li>
                                    <li class="col-md-2"><a href="#">Bóng đá Pháp</a></li>
                                    <li class="col-md-2"><a href="#">Tiêu điểm </a></li>
                                    <li class="col-md-2"><a href="#">Lịch thi đấu bóng đá</a></li>
                                    <li class="col-md-2"><a href="#">Phiên bản Mobile </a></li>


                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <ul class="list-logo">
                            <li><a href="#"><img src="images/lg1.png"/></a></li>
                            <li><a href="#"><img src="images/lg2.png"/></a></li>
                            <li><a href="#"><img src="images/lg3.png"/></a></li>
                            <li><a href="#"><img src="images/lg4.png"/></a></li>
                            <li><a href="#"><img src="images/lg5.png"/></a></li>
                            <li><a href="#"><img src="images/lg6.png"/></a></li>
                            <li><a href="#"><img src="images/lg7.png"/></a></li>
                            <li><a href="#"><img src="images/lg8.png"/></a></li>
                            <li><a href="#"><img src="images/lg9.png"/></a></li>
                            <li><a href="#"><img src="images/lg10.png"/></a></li>
                            <li><a href="#"><img src="images/lg11.png"/></a></li>
                            <li><a href="#"><img src="images/lg12.png"/></a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="container-fuild bottom-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-2 text-center">
                            <a href="#"><img src="images/logo-footer.png"/></a></br></br>
                            <a href="#"><img src="images/logo-dmca.png"/></a>
                        </div>
                        <div class="col-md-5">
                            <h3>Trang tin điện tử Bongda24h - Chuyên trang bóng đá hàng đầu tại Việt Nam</h3>
                            <p>Giấy phép thiết lập trang Thông tin điện tử tổng hợp số: 1183/GP-TTĐT cấp ngày 04/04/2016 bởi Sở TT-TT Hà Nội, thay thế giấy phép 258/GP-TTĐT cấp ngày 07/04/2011 bởi Sở TT-TT Hà Nội 
                                Nội dung thông tin hợp tác giữa báo Điện tử Thể thao Việt Nam và công ty Incom </p>	
                        </div>
                        <div class="col-md-5">
                            <p><span>Đơn vị chủ quản:</span>
                                Công ty Cổ phần Truyền thông quốc tế INCOM</p>
                            <p><span>Chịu trách nhiệm:</span> Ông Vũ Mạnh Cường </p>
                            <p><span>Địa chỉ:</span> Tầng 3 Toà nhà IC, Số 82 Phố Duy Tân, phường Dịch Vọng Hậu, Cầu Giấy, Hà Nội </p>
                            <p><span>Tel:</span> (04) 3.784 8888 - <span>Fax:</span> (04) 3.7833699 * </p>
                            <p><span>Email:</span> bongda24h@incom.vn </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>


        <?php $this->endBody() ?>
    </body>
</html>
<?php $this->endPage() ?>
