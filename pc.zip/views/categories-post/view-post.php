<?php
/*
 * *********************************************
 * @author:XuanDacIT <xuandac990@gmail.com>
 * Time:Sep 28, 2017, 2:01:27 PM. 
 * *********************************************
 */

use app\services\PostService;
use yii\web\View;

$Config = Yii::$app->params;
$Url_Media = $Config['media'];
$Service = new PostService();

$Data_Post = $Data['data'];
$Seo_tile = $Data_Post['SEO_Title'];
if ($Data_Post['SEO_Title'] == null) {
    $Seo_tile = $Data_Post['Title'];
}

$canonical = $Data_Post['SEO_Canonical'];
if ($Data_Post['SEO_Canonical'] == null) {
    $canonical = $Config['site_domain'] . $_SERVER['REQUEST_URI'];
}
$this->title = $Seo_tile;
$this->registerLinkTag(['rel' => "canonical", 'href' => $canonical]);
$this->registerMetaTag([
    'name' => 'keywords',
    'content' => $Data_Post['SEO_Keywords'],
]);
$this->registerMetaTag([
    'name' => 'description',
    'content' => $Data_Post['SEO_Description'],
]);
?>
<div id="box_panel1" class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-10">
                    <div class="row">
                        <div class="container-detail">
                            <div class="col-md-12">
                                <div class="top-detail clearfix">
                                    <time class="pull-lefft">Thứ 2, 15/0/2017 | 2:50</time>
                                    <ul class="list-extent pull-right">
                                        <li class="fb"><a href="#"><i class="fa fa-facebook-official" aria-hidden="true"></i></a></li>
                                        <li class="tw"><a href="#"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
                                        <li class="gp"><a href="#"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
                                        <li class="pr"><a href="#"><i class="fa fa-print" aria-hidden="true"></i></a></li>
                                        <li class="em"><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
                                    </ul>
                                </div>


                                <h1 class="name-post"><?= $Data_Post['Title'] ?></h1>
                                <ul class="list-tags">
                                    <li><a href="#">Liverpool</a></li>
                                    <li><a href="#">Chelsea</a></li>
                                </ul>


                            </div>
                            <div class="col-md-12">
                                <div class="summary clear"><?= $Data_Post['Summary'] ?></div>                                
                            </div>
                            <div class="col-md-12">
                                <ul class="list-new-top">
                                    <?php foreach ($Data_Post_Tags as $key => $value) { ?>
                                        <li><a href="<?= $Service->makeUrl($value) ?>"><?= $value['Title'] ?></a></li>
                                    <?php } ?>
                                </ul>
                            </div>

                            <div class="col-md-12">
                                <div class="content-post"><?= $Data_Post['Content'] ?></div>
                            </div>
                            <section class="box-item-detail">
                                <div class="col-md-12">
                                    <div class="title-box-detail clearfix">
                                        <h2>Tin liên quan đến Ronaldo</h2>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="list-item-top clearfix">
                                        <div class="row">


                                            <div class="col-md-4">
                                                <div class="img">
                                                    <a href="#"><img src="images/h20.jpg"/></a>
                                                </div>
                                                <h3><a href="#">Ronaldo bị cấm thi đấu năm trận vì đẩy trọng tài</a></h3>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="img">
                                                    <a href="#"><img src="images/h20.jpg"/></a>
                                                </div>
                                                <h3><a href="#">Ronaldo bị cấm thi đấu năm trận vì đẩy trọng tài</a></h3>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="img">
                                                    <a href="#"><img src="images/h20.jpg"/></a>
                                                </div>
                                                <h3><a href="#">Ronaldo bị cấm thi đấu năm trận vì đẩy trọng tài</a></h3>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <ul class="list-post-box-detail">
                                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <div class="box-adv">
                                        <a href="#"><img src="images/adv10.jpg"></a>
                                    </div>
                                </div>
                            </section>

                            <section class="box-item-detail">
                                <div class="col-md-12">
                                    <div class="title-box-detail clearfix">
                                        <h2>Tin sự kiện liên quan</h2>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="list-item-top clearfix">
                                        <div class="row">

                                            <?php
                                            foreach ($Data_Post_Tieu_Diem as $i => $index) {
                                                if ($i == 3) {
                                                    break;
                                                }
                                                $List_Img = json_decode($index['Thumb'], true);
                                                ?>
                                                <div class="col-md-4">
                                                    <div class="img">
                                                        <a href="<?= $Service->makeUrl($index) ?>"><img src="<?= $Url_Media . $List_Img['size1'] ?>"/></a>
                                                    </div>
                                                    <h3><a href="<?= $Service->makeUrl($index) ?>"><?= $index['Title'] ?></a></h3>
                                                </div>
                                                <?php
                                                unset($Data_Post_Tieu_Diem[$i]);
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>

                                <?php
                                foreach ($Data_Post_Tieu_Diem as $i => $index) {
                                    $List_Img = json_decode($index['Thumb'], true);
                                    ?>
                                    <div class="col-md-6 list-it">
                                        <div class="item-small">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <a href="<?= $Service->makeUrl($index) ?>"><img src="<?= $Url_Media . $List_Img['size1'] ?>"/></a>
                                                </div>
                                                <div class="col-md-8">
                                                    <h3><a href="<?= $Service->makeUrl($index) ?>"><?= $index['Title'] ?></a></h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>





                            </section>


                            <section class="box-item-detail">
                                <div class="col-md-12">
                                    <div class="title-box-detail clearfix">
                                        <?php
                                        $List_Category = explode(',', $Data_Post['NameCategories']);
                                        ?>
                                        <h2><?= $List_Category[1] ?></h2>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="list-item-top clearfix">
                                        <div class="row">

                                            <?php
                                            foreach ($Data['data_same'] as $j => $item) {
                                                if ($j == 3) {
                                                    break;
                                                }
                                                $List_Img = json_decode($item['Thumb'], true);
                                                ?>
                                                <div class="col-md-4">
                                                    <div class="img">
                                                        <a href="<?= $Service->makeUrl($item) ?>"><img src="<?= $Url_Media . $List_Img['size1'] ?>"/></a>
                                                    </div>
                                                    <h3><a href="<?= $Service->makeUrl($item) ?>"><?= $item['Title'] ?></a></h3>
                                                </div>
                                                <?php
                                                unset($Data['data_same'][$j]);
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>
                                <?php
                                foreach ($Data['data_same'] as $j => $item) {
                                    $List_Img = json_decode($item['Thumb'], true);
                                    ?>
                                    <div class="col-md-6 list-it">
                                        <div class="item-small">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <a href="<?= $Service->makeUrl($item) ?>"><img src="<?= $Url_Media . $List_Img['size1'] ?>"/></a>
                                                </div>
                                                <div class="col-md-8">
                                                    <h3><a href="<?= $Service->makeUrl($item) ?>"><?= $item['Title'] ?></a></h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                <?php } ?>                   



                            </section>


                            <section class="box-item-detail">
                                <div class="col-md-12">
                                    <div class="title-box-detail clearfix">
                                        <h2>Video <?= $List_Category[1] ?></h2>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="list-video-detail pull-left">
                                        <div class="row">
                                            <div class="col-md-4 itemm-box-video">
                                                <div class="img-vd">
                                                    <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                                    <a href="#"><img src="images/a5.jpg"/></a>
                                                </div>
                                                <div class="caption-video">
                                                    <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                                    <p>(ICC 2017)</p>
                                                </div>
                                            </div>
                                            <div class="col-md-4 itemm-box-video">
                                                <div class="img-vd">
                                                    <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                                    <a href="#"><img src="images/a6.jpg"/></a>
                                                </div>
                                                <div class="caption-video">
                                                    <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                                    <p>(ICC 2017)</p>
                                                </div>
                                            </div>
                                            <div class="col-md-4 itemm-box-video">
                                                <div class="img-vd">
                                                    <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                                    <a href="#"><img src="images/a7.jpg"/></a>
                                                </div>
                                                <div class="caption-video">
                                                    <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                                    <p>(ICC 2017)</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </section>
                        </div>












                    </div>

                </div>

                <div class="col-md-2 box-ltd">
                    <div class="row">
                        <div class="col-md-12 first-new">
                            <a href="#">
                                <img src="images/a13.jpg">
                            </a>
                            <h3><a href="#">Những điểm nhấn sau trận đấu Chelsea 2-3 Bayern </a></h3>
                        </div>						

                    </div>

                    <ul class="list-first-new">
                        <li><a href="#">HLV Hữu Thắng chia sẻ về tình trạng sức khỏe của bản thân</a></li>
                        <li><a href="#">Bầu Đức thưởng 1 tỷ cho U22 Việt Nam sau chiến tích giành vé dự VCK U23 châu Á</a></li>
                        <li><a href="#">U22 Thái Lan tập hợp đội hình để săn vàng SEA Games 29</a></li>
                        <li><a href="#">U22 Việt Nam thắng đội hạng 3 Hàn Quốc nhờ cú đúp của Đức Chinh</a></li>
                    </ul>
                    <div class="box-adv adv2">
                        <a href="#"><img src="images/adv7.png"/></a>
                    </div>

                </div>





            </div>
        </div>
        <div class="col-md-3 slidebar-left">


            <div class="box-adv adv-4">
                <a href="#"><img src="images/adv4.jpg"/></a>
            </div>
            <div class="row">
                <div class="col-sm-12 title-slidebar">
                    <h2><a href="#">Video</a></h2>
                </div>

                <div class="col-sm-12">
                    <div class="top-video-slidebar class">
                        <a href="#">
                            <img src="images/a12.jpg"/>
                        </a>
                        <span class="icon-video">
                            <img src="images/ic-vd1.png" />
                            live
                        </span>
                        <h3><a href="#">Những điểm nhấn sau trận đấu Chelsea 2-3 Bayern Munich</a></h3>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="slide-video-slidebar owl-carousel owl-theme" data-items="2" data-nav="false" data-dots="true" data-loop="false" data-margin="15">
                        <div class="item">
                            <a href="#">
                                <img src="images/h20.jpg"/>
                                <span>Ronaldo đẩy trọng tài sau khi nhận thẻ đỏ</span>
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="images/h20.jpg"/>
                                <span>Ronaldo đẩy trọng tài sau khi nhận thẻ đỏ</span>
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="images/h20.jpg"/>
                                <span>Ronaldo đẩy trọng tài sau khi nhận thẻ đỏ</span>
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="images/h20.jpg"/>
                                <span>Ronaldo đẩy trọng tài sau khi nhận thẻ đỏ</span>
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="images/h20.jpg"/>
                                <span>Ronaldo đẩy trọng tài sau khi nhận thẻ đỏ</span>
                            </a>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-sm-12 title-slidebar">
                    <h2><a href="#">Champions League</a></h2>
                </div>
                <div class="col-sm-12">
                    <div class="item-top-slidebar clear">
                        <h3><a href="#">Ngoại hạng Anh Carragher: 'Có gì đó không đúng đang diễn ra ở Chelsea'  </a></h3>
                        <div class="row">
                            <div class="col-sm-6 img-post-slidebar">
                                <a href="#">
                                    <img src="images/h20.jpg" />
                                </a>
                            </div>
                            <div class="col-sm-6 shot-des">
                                <p>Cựu danh thủ Liverpool cho rằng Antonio Conte và các học trò cần giữ bình ...</p>
                            </div>
                        </div>
                    </div>

                    <ul class="list-item-slidebar">
                        <li><a href="#">Sao Man City dự đoán một Leicester 2.0 trong mùa giải mới</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                    </ul>
                </div>
            </div>


            <div class="row">
                <div class="col-sm-12 title-slidebar">
                    <h2><a href="#">Serie A</a></h2>
                </div>
                <div class="col-sm-12">
                    <div class="item-top-slidebar clear">
                        <h3><a href="#">Ngoại hạng Anh Carragher: 'Có gì đó không đúng đang diễn ra ở Chelsea'  </a></h3>
                        <div class="row">
                            <div class="col-sm-6 img-post-slidebar">
                                <a href="#">
                                    <img src="images/h20.jpg" />
                                </a>
                            </div>
                            <div class="col-sm-6 shot-des">
                                <p>Cựu danh thủ Liverpool cho rằng Antonio Conte và các học trò cần giữ bình ...</p>
                            </div>
                        </div>
                    </div>

                    <ul class="list-item-slidebar">
                        <li><a href="#">Sao Man City dự đoán một Leicester 2.0 trong mùa giải mới</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                    </ul>
                </div>
            </div>
            <div class="box-adv adv-4">
                <a href="#"><img src="images/adv10.jpg"/></a>
            </div>
            <div class="row">
                <div class="col-sm-12 title-slidebar">
                    <h2><a href="#">Tin trong nước</a></h2>
                </div>
                <div class="col-sm-12">
                    <div class="item-top-slidebar clear">
                        <h3><a href="#">Ngoại hạng Anh Carragher: 'Có gì đó không đúng đang diễn ra ở Chelsea'  </a></h3>
                        <div class="row">
                            <div class="col-sm-6 img-post-slidebar">
                                <a href="#">
                                    <img src="images/h20.jpg" />
                                </a>
                            </div>
                            <div class="col-sm-6 shot-des">
                                <p>Cựu danh thủ Liverpool cho rằng Antonio Conte và các học trò cần giữ bình ...</p>
                            </div>
                        </div>
                    </div>

                    <ul class="list-item-slidebar">
                        <li><a href="#">Sao Man City dự đoán một Leicester 2.0 trong mùa giải mới</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                    </ul>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12 title-slidebar">
                    <h2>Các đội bóng</h2>
                </div>
                <div class="col-sm-12">
                    <select class="form-control select-team">
                        <option>Laliga</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                    </select>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-mu.png" />
                                    Mancheter United
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-chs.png" />
                                    Chelsea
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-mu.png" />
                                    Mancheter United
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-chs.png" />
                                    Chelsea
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-mu.png" />
                                    Mancheter United
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-chs.png" />
                                    Chelsea
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-mu.png" />
                                    Mancheter United
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-chs.png" />
                                    Chelsea
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-mu.png" />
                                    Mancheter United
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-chs.png" />
                                    Chelsea
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-adv adv-4">
                <a href="#"><img src="images/adv10.jpg"/></a>
            </div>

            <div class="row">
                <div class="col-sm-12 title-yk">
                    <h2>Thăm dò ý kiến</h2>
                </div>
                <div class="col-sm-12">
                    <div class="list-yk clear">
                        <p>Đội bóng nào sẽ vô địch Premier League 2017/18?</p>
                        <div class="radio-team">
                            <input class="magic-radio" type="radio" id="1" name="radio"  value="option1">
                            <label for="1">
                                <img src="images/logo-chs.png" />
                                Chelsea
                            </label>
                        </div>
                        <div class="radio-team">
                            <input class="magic-radio" type="radio" id="2" name="radio"  value="option1">
                            <label for="2">
                                <img src="images/logo-chs.png" />
                                Chelsea
                            </label>
                        </div>

                        <div class="radio-team">
                            <input class="magic-radio" type="radio" id="3" name="radio"  value="option1">
                            <label for="3">
                                <img src="images/logo-chs.png" />
                                Chelsea
                            </label>
                        </div>
                        <div class="radio-team">
                            <input class="magic-radio" type="radio" id="4" name="radio"  value="option1">
                            <label for="4">
                                <img src="images/logo-chs.png" />
                                Chelsea
                            </label>
                        </div>

                        <div class="radio-team">
                            <input class="magic-radio" type="radio" id="5" name="radio"  value="option1">
                            <label for="5">
                                <img src="images/logo-chs.png" />
                                Chelsea
                            </label>
                        </div>
                        <div class="buttom-yk text-center">
                            <button class="btn-bc">Bình chọn</button>
                            <button class="btn-kq">Kết quả</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div> 
