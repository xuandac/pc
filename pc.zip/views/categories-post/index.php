<?php
/*
 * *********************************************
 * @author:XuanDacIT <xuandac990@gmail.com>
 * Time:Sep 28, 2017, 2:01:27 PM. 
 * *********************************************
 */
use app\services\PostService;
use yii\widgets\LinkPager;

$this->title = 'Kết quả nhanh';
$Config = Yii::$app->params;
$Url_Media = $Config['media'];
$Service = new PostService();
?>
<div id="box_panel1" class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-10">
                    <div class="row">
                        <div class="item-one">
                            
                            <?php 
                            if(count($Data_Hot)>0){
                              $Img_Top = json_decode($Data_Hot[0]['Thumb'],true);  
                            ?>
                            <div class="col-md-4">
                                <h3 class="name-post"><a href="<?= $Service->makeUrl($Data_Hot[0])?>"><?= $Data_Hot[0]['Title']?></a></h3>
                                <p class="text-justify"><?= $Service->subStringv($Data_Hot[0]['Summary'], 150)?></p>
                                <ul class="list-tags">
                                    <li><a href="#">Liverpool</a></li>
                                    <li><a href="#">Chelsea</a></li>
                                </ul>
                            </div>
                            <div class="col-md-8">
                                <div class="img">
                                    <a href="<?= $Service->makeUrl($Data_Hot[0]);?>"><img src="<?= $Url_Media.$Img_Top['size1']?>"/></a>
                                </div>
                            </div>
                            <?php 
                            unset($Data_Hot[0]); }                             
                            ?>
                            <?php
                            foreach ($Data_Hot as $key=>$value){
                            ?>
                            <div class="col-md-4 item-box-one">
                                <h3><a href="<?= $Service->makeUrl($value)?>"><?= $value['Title']?></a></h3>
                            </div>
                            <?php } ?>


                        </div>

                        <div class="col-md-12">
                            <div class="list-video-category pull-left">
                                <div class="row">
                                    <div class="col-md-4 itemm-box-video">
                                        <div class="img-vd">
                                            <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                            <a href="#"><img src="images/a5.jpg"/></a>
                                        </div>
                                        <div class="caption-video">
                                            <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                            <p>(ICC 2017)</p>
                                        </div>
                                    </div>
                                    <div class="col-md-4 itemm-box-video">
                                        <div class="img-vd">
                                            <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                            <a href="#"><img src="images/a6.jpg"/></a>
                                        </div>
                                        <div class="caption-video">
                                            <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                            <p>(ICC 2017)</p>
                                        </div>
                                    </div>
                                    <div class="col-md-4 itemm-box-video">
                                        <div class="img-vd">
                                            <a href="#" class="play-video"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a>
                                            <a href="#"><img src="images/a7.jpg"/></a>
                                        </div>
                                        <div class="caption-video">
                                            <h3><a href="#">Chelsea 2 - 3 Bayer Munich</a> </h3>
                                            <p>(ICC 2017)</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="list-new-category">
                            <?php
                                                    foreach ($Data_Post_cat as  $i=>$item){
                                                      $List_img = json_decode($item['Thumb'], true);
                            ?>
                            <div class="col-md-12 item-list-new">
                                <div class="content-item-list-new">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="img">
                                                <a href="<?= $Service->makeUrl($item);?>"><img src="<?=  $Url_Media.$List_img['size1']?>"/></a>
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="caption-it">
                                                <h3><a href="<?= $Service->makeUrl($item);?>"><?= $item['Title']?></a></h3>
                                                <p><?= $Service->subStringv($item['Summary'], 220)?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                                    <?php } ?>
                            
                           
                           
                           
                        

                            <div class="col-md-12">
                                <nav class="pull-right">
                                   <?= LinkPager::widget(['pagination' => $pagination,]) ?>
                                </nav>
                            </div>
                        </div>


                    </div>
                </div>
                <div class="col-md-2 box-ltd">
                    <div class="row">
                        <div class="col-md-12 first-new">
                            <a href="#">
                                <img src="images/a13.jpg">
                            </a>
                            <h3><a href="#">Những điểm nhấn sau trận đấu Chelsea 2-3 Bayern </a></h3>
                        </div>						

                    </div>

                    <ul class="list-first-new">
                        <li><a href="#">HLV Hữu Thắng chia sẻ về tình trạng sức khỏe của bản thân</a></li>
                        <li><a href="#">Bầu Đức thưởng 1 tỷ cho U22 Việt Nam sau chiến tích giành vé dự VCK U23 châu Á</a></li>
                        <li><a href="#">U22 Thái Lan tập hợp đội hình để săn vàng SEA Games 29</a></li>
                        <li><a href="#">U22 Việt Nam thắng đội hạng 3 Hàn Quốc nhờ cú đúp của Đức Chinh</a></li>
                    </ul>
                    <div class="box-adv adv2">
                        <a href="#"><img src="images/adv7.png"/></a>
                    </div>

                </div>

                <!-- Bảng xếp hạng ---->
                <div class="col-md-12">
                    <div class="title-box5 title-box-category">
                        <div class="left-title-box5 pull-left">
                            <img src="images/ic-cl.png"/>
                            <span>Lịch thi đấu - Kết quả bóng đá</span>
                        </div>


                    </div>
                </div>

                <div class="col-md-12">
                    <div class="sub-title-box5">
                        <img src="images/lg-p.png"/>
                        <span>LTĐ Premier League  2017 (Vòng 3)</span>
                    </div>
                </div>

                <div class="col-md-3">
                    <table class="tbl-vong-dau">
                        <tbody>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr class="v-f">
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                            <tr>
                                <td class="v">Vòng 1</td>
                                <td class="d-v">17/8 - 22/8</td>								
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-9">
                    <table class="ltd-kq-box5">
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-mu.png"/> Mancheter United</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-ev.png"/> Southamton</td>
                            <td class="ac"><i class="fa fa-star f-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-mu.png"/> Mancheter United</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-ev.png"/> Southamton</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-mu.png"/> Mancheter United</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-ev.png"/> Southamton</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><span>23:03</span></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-mu.png"/> Mancheter United</td>
                            <td class="kq"><strong>0 : 2</strong></td>
                            <td class="t-td-last"><img src="images/logo-ev.png"/> Southamton</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><strong>0 : 0</strong></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-mu.png"/> Mancheter United</td>
                            <td class="kq"><strong>3 : 0</strong></td>
                            <td class="t-td-last"><img src="images/logo-ev.png"/> Southamton</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>
                        <tr>
                            <td class="d-td">Thứ 7 	&nbsp; 17/8</td>
                            <td class="t-td"><img src="images/logo-by.png"/> Bayern Munich</td>
                            <td class="kq"><strong>3 : 0</strong></td>
                            <td class="t-td-last"><img src="images/logo-chs.png"/> Chelsea</td>
                            <td class="ac"><i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-info" aria-hidden="true"></i></td>
                        </tr>

                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-3 slidebar-left">


            <div class="box-adv adv-4">
                <a href="#"><img src="images/adv4.jpg"/></a>
            </div>
            <div class="row">
                <div class="col-sm-12 title-slidebar">
                    <h2><a href="#">Video</a></h2>
                </div>

                <div class="col-sm-12">
                    <div class="top-video-slidebar class">
                        <a href="#">
                            <img src="images/a12.jpg"/>
                        </a>
                        <span class="icon-video">
                            <img src="images/ic-vd1.png" />
                            live
                        </span>
                        <h3><a href="#">Những điểm nhấn sau trận đấu Chelsea 2-3 Bayern Munich</a></h3>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="slide-video-slidebar owl-carousel owl-theme" data-items="2" data-nav="false" data-dots="true" data-loop="false" data-margin="15">
                        <div class="item">
                            <a href="#">
                                <img src="images/h20.jpg"/>
                                <span>Ronaldo đẩy trọng tài sau khi nhận thẻ đỏ</span>
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="images/h20.jpg"/>
                                <span>Ronaldo đẩy trọng tài sau khi nhận thẻ đỏ</span>
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="images/h20.jpg"/>
                                <span>Ronaldo đẩy trọng tài sau khi nhận thẻ đỏ</span>
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="images/h20.jpg"/>
                                <span>Ronaldo đẩy trọng tài sau khi nhận thẻ đỏ</span>
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="images/h20.jpg"/>
                                <span>Ronaldo đẩy trọng tài sau khi nhận thẻ đỏ</span>
                            </a>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-sm-12 title-slidebar">
                    <h2><a href="#">Champions League</a></h2>
                </div>
                <div class="col-sm-12">
                    <div class="item-top-slidebar clear">
                        <h3><a href="#">Ngoại hạng Anh Carragher: 'Có gì đó không đúng đang diễn ra ở Chelsea'  </a></h3>
                        <div class="row">
                            <div class="col-sm-6 img-post-slidebar">
                                <a href="#">
                                    <img src="images/h20.jpg" />
                                </a>
                            </div>
                            <div class="col-sm-6 shot-des">
                                <p>Cựu danh thủ Liverpool cho rằng Antonio Conte và các học trò cần giữ bình ...</p>
                            </div>
                        </div>
                    </div>

                    <ul class="list-item-slidebar">
                        <li><a href="#">Sao Man City dự đoán một Leicester 2.0 trong mùa giải mới</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                    </ul>
                </div>
            </div>


            <div class="row">
                <div class="col-sm-12 title-slidebar">
                    <h2><a href="#">Serie A</a></h2>
                </div>
                <div class="col-sm-12">
                    <div class="item-top-slidebar clear">
                        <h3><a href="#">Ngoại hạng Anh Carragher: 'Có gì đó không đúng đang diễn ra ở Chelsea'  </a></h3>
                        <div class="row">
                            <div class="col-sm-6 img-post-slidebar">
                                <a href="#">
                                    <img src="images/h20.jpg" />
                                </a>
                            </div>
                            <div class="col-sm-6 shot-des">
                                <p>Cựu danh thủ Liverpool cho rằng Antonio Conte và các học trò cần giữ bình ...</p>
                            </div>
                        </div>
                    </div>

                    <ul class="list-item-slidebar">
                        <li><a href="#">Sao Man City dự đoán một Leicester 2.0 trong mùa giải mới</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                    </ul>
                </div>
            </div>
            <div class="box-adv adv-4">
                <a href="#"><img src="images/adv10.jpg"/></a>
            </div>
            <div class="row">
                <div class="col-sm-12 title-slidebar">
                    <h2><a href="#">Tin trong nước</a></h2>
                </div>
                <div class="col-sm-12">
                    <div class="item-top-slidebar clear">
                        <h3><a href="#">Ngoại hạng Anh Carragher: 'Có gì đó không đúng đang diễn ra ở Chelsea'  </a></h3>
                        <div class="row">
                            <div class="col-sm-6 img-post-slidebar">
                                <a href="#">
                                    <img src="images/h20.jpg" />
                                </a>
                            </div>
                            <div class="col-sm-6 shot-des">
                                <p>Cựu danh thủ Liverpool cho rằng Antonio Conte và các học trò cần giữ bình ...</p>
                            </div>
                        </div>
                    </div>

                    <ul class="list-item-slidebar">
                        <li><a href="#">Sao Man City dự đoán một Leicester 2.0 trong mùa giải mới</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                        <li><a href="#">Man City đặt mục tiêu hạ bệ Real Madrid ở Champions League</a></li>
                    </ul>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12 title-slidebar">
                    <h2>Các đội bóng</h2>
                </div>
                <div class="col-sm-12">
                    <select class="form-control select-team">
                        <option>Laliga</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                    </select>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-mu.png" />
                                    Mancheter United
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-chs.png" />
                                    Chelsea
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-mu.png" />
                                    Mancheter United
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-chs.png" />
                                    Chelsea
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-mu.png" />
                                    Mancheter United
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-chs.png" />
                                    Chelsea
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-mu.png" />
                                    Mancheter United
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-chs.png" />
                                    Chelsea
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-mu.png" />
                                    Mancheter United
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="item-team">
                                <a href="#">
                                    <img src="images/logo-chs.png" />
                                    Chelsea
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-adv adv-4">
                <a href="#"><img src="images/adv10.jpg"/></a>
            </div>

            <div class="row">
                <div class="col-sm-12 title-yk">
                    <h2>Thăm dò ý kiến</h2>
                </div>
                <div class="col-sm-12">
                    <div class="list-yk clear">
                        <p>Đội bóng nào sẽ vô địch Premier League 2017/18?</p>
                        <div class="radio-team">
                            <input class="magic-radio" type="radio" id="1" name="radio"  value="option1">
                            <label for="1">
                                <img src="images/logo-chs.png" />
                                Chelsea
                            </label>
                        </div>
                        <div class="radio-team">
                            <input class="magic-radio" type="radio" id="2" name="radio"  value="option1">
                            <label for="2">
                                <img src="images/logo-chs.png" />
                                Chelsea
                            </label>
                        </div>

                        <div class="radio-team">
                            <input class="magic-radio" type="radio" id="3" name="radio"  value="option1">
                            <label for="3">
                                <img src="images/logo-chs.png" />
                                Chelsea
                            </label>
                        </div>
                        <div class="radio-team">
                            <input class="magic-radio" type="radio" id="4" name="radio"  value="option1">
                            <label for="4">
                                <img src="images/logo-chs.png" />
                                Chelsea
                            </label>
                        </div>

                        <div class="radio-team">
                            <input class="magic-radio" type="radio" id="5" name="radio"  value="option1">
                            <label for="5">
                                <img src="images/logo-chs.png" />
                                Chelsea
                            </label>
                        </div>
                        <div class="buttom-yk text-center">
                            <button class="btn-bc">Bình chọn</button>
                            <button class="btn-kq">Kết quả</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div> 
