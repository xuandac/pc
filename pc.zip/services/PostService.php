<?php

/*
 * *********************************************
 * @author:XuanDacIT <xuandac990@gmail.com>
 * Time:Sep 22, 2017, 9:16:41 AM. 
 * *********************************************
 */

namespace app\services;

use app\models\Post;
use yii\db\Expression;
use yii\db\Query;
use yii\data\Pagination;

class PostService {

    public function get_post($limit = null, $where) {
        $date = date('Y-m-d H:i:s');
        $query = Post::find();
        /* $pagination = new Pagination([
          'defaultPageSize' => 2,
          'totalCount' => $query->count(),
          ]); */

        $data = $query->orderBy('id DESC')
                ->limit($limit)
                ->where($where)
                ->andWhere(['IsDelete' => 0, 'Status' => 1])
                ->andWhere(['<=', 'DatePublic', $date])
                ->asArray()
                ->all();
        return array('data' => $data);
    }

    public function get_post_hot_categories($id_categories) {
        $query = new Query();
        $Data_Post = $query->select([
                    'a.ID', 'a.Title', 'a.Summary', 'a.Slug', 'a.Thumb', 'a.DateCreate',
                    'b.CategoriesId',
                    'c.ID as Cat_Id',
                ])->from('post as a')
                ->innerJoin('post_categories as b', 'a.ID = b.PostId')
                ->innerJoin('categories as c', 'b.CategoriesId = c.ID')
                ->limit(7)
                ->orderBy('c.ID DESC')
                ->where(['c.ID' => $id_categories, 'a.hot' => 1, 'a.Status' => 1, 'a.IsDelete' => 0])
                ->andWhere(['<=', 'a.DatePublic', date('Y-m-d H:i:s')])
                // ->asArray()            
                ->all();

        return array('data' => $Data_Post);
    }

    public function get_post_categories($id_categories) {
        $Data_Hot = $this->get_post_hot_categories($id_categories);
        $Array_Id_hot = [];
        foreach ($Data_Hot['data'] as $key => $value) {
            array_push($Array_Id_hot, $value['ID']);
        }

        $query = new Query();
        $query->select([
                    'a.ID', 'a.Title', 'a.Summary', 'a.Slug', 'a.Thumb', 'a.DateCreate',
                    'b.CategoriesId',
                    'c.ID',
                ])->from('post as a')
                ->innerJoin('post_categories as b', 'a.ID = b.PostId')
                ->innerJoin('categories as c', 'b.CategoriesId = c.ID')
                ->orderBy('c.ID DESC')
                ->where(['c.ID' => $id_categories, 'a.Status' => 1, 'a.IsDelete' => 0])
                ->andWhere(['not in', 'a.ID', $Array_Id_hot])
                ->andWhere(['<=', 'a.DatePublic', date('Y-m-d H:i:s')]);
        //->all();
        $pagination = new Pagination([
            'defaultPageSize' => 12,
            'totalCount' => $query->count()
        ]);
        $Data_Post = $query->offset($pagination->offset)
                ->limit($pagination->limit)
                ->all();

        return array('data' => $Data_Post, 'pagination' => $pagination);
    }

    public function view_post($slug) {
        $date = date('Y-m-d H:i:s');
        $query = new Query();
        $Data_Post = $query->select([
                    'a.ID', 'a.Title', 'a.Summary', 'a.Content', 'a.Slug', 'a.Thumb', 'a.Tags', 'a.DateCreate',
                    'a.SEO_Title', 'a.SEO_Description', 'a.SEO_Keywords', 'a.SEO_Canonical',
                    'b.CategoriesID', 'GROUP_CONCAT(b.CategoriesID SEPARATOR ",") AS CategoriesId',
                    'GROUP_CONCAT(c.Title SEPARATOR ",") AS NameCategories',
                ])->from('post as a')
                ->leftJoin('post_categories as b', 'a.ID = b.PostId')
                ->leftJoin('categories as c', 'b.CategoriesID = c.ID')
                ->where(['a.Slug' => $slug, 'a.Status' => 1, 'a.IsDelete' => 0])
                ->andWhere(['<=', 'a.DatePublic', $date])
                // ->groupBy(['b.PostId'])
                // ->asArray()
                ->one();
        $Data_same = $this->get_post_same($Data_Post);

        return array('data' => $Data_Post, 'data_same' => $Data_same);
    }

    public function get_post_same($Data_Post) {
        $Array_Cat = explode(',', $Data_Post['CategoriesID']);

        $query = new Query();
        $Data = $query->select([
                    'a.ID', 'a.Title', 'a.Summary', 'a.Slug', 'a.Thumb', 'a.DateCreate'
                ])->from('post as a')
                ->innerJoin('post_categories as b', 'a.ID = b.PostId')
                ->innerJoin('categories as c', 'b.CategoriesId = c.ID')
                ->limit(9)
                ->orderBy('a.ID DESC')
                ->where(['c.ID' => $Array_Cat[0], 'a.Status' => 1, 'a.IsDelete' => 0])
                ->andWhere(['<=', 'a.DatePublic', date('Y-m-d H:i:s')])
                // ->asArray()            
                ->all();
        return $Data;
    }
    
      public function get_post_tieu_diem_lq($id_post = null, $array_tags = array()) {
        $date = date('Y-m-d H:i:s');
        $query = Post::find();
        /* $pagination = new Pagination([
          'defaultPageSize' => 2,
          'totalCount' => $query->count(),
          ]); */
        if (count($array_tags) > 0) {
            foreach ($array_tags as $value) {
                $query->orWhere(['like', 'Tags', $value]);
            }
        }
        $query->orderBy(new Expression('rand()'))
                ->limit(9)
                ->andWhere(['!=', 'ID', $id_post])
                ->andWhere(['Focus' => 1])
                ->andWhere(['Status' => 1, 'IsDelete' => 0,])
                ->andWhere(['<=', 'DatePublic', $date]);

        $data = $query->asArray()->all();
        return array('data' => $data);
    }
    
    public function get_post_tags($id_post = null, $array_tags = array()) {
        $date = date('Y-m-d H:i:s');
        $query = Post::find();
        /* $pagination = new Pagination([
          'defaultPageSize' => 2,
          'totalCount' => $query->count(),
          ]); */
        if (count($array_tags) > 0) {
            foreach ($array_tags as $value) {
                $query->orWhere(['like', 'Tags', $value]);
            }
        }
        $query->orderBy(new Expression('rand()'))
                ->limit(3)
                ->andWhere(['!=', 'ID', $id_post])
                ->andWhere(['Status' => 1, 'IsDelete' => 0,])
                ->andWhere(['<=', 'DatePublic', $date]);

        $data = $query->asArray()->all();
        return array('data' => $data);
    }
    public static function makeUrl($data_post, $full = false) {
        $name_post = $data_post['Title'];
        $url = '/' . (isset($data_post['Slug']) ? $data_post['Slug'] : self::makeAlias($name_post));

        if ($full)
            $url = 'http://' . \Yii::$app->params['site_domain'] . $url;
        return $url;
    }

    public static function makeUrl_Categoies($data_post, $full = false) {
        $name_post = $data_post['Title'];
        $url = '/' . (isset($data_post['Slug']) ? $data_post['Slug'] . '-c' . $data_post['ID'] : self::makeAlias($name_post));

        if ($full)
            $url = 'http://' . \Yii::$app->params['site_domain'] . $url;
        return $url;
    }

    public static function makeAlias($str, $lowerCase = true) {
        $search = array(
            '#(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)#',
            '#(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)#',
            '#(ì|í|ị|ỉ|ĩ)#',
            '#(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)#',
            '#(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)#',
            '#(ỳ|ý|ỵ|ỷ|ỹ)#',
            '#(đ)#',
            '#(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)#',
            '#(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)#',
            '#(Ì|Í|Ị|Ỉ|Ĩ)#',
            '#(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)#',
            '#(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)#',
            '#(Ỳ|Ý|Ỵ|Ỷ|Ỹ)#',
            '#(Đ)#',
            "/[^a-zA-Z0-9\-\_]/",
        );
        $replace = array(
            'a',
            'e',
            'i',
            'o',
            'u',
            'y',
            'd',
            'A',
            'E',
            'I',
            'O',
            'U',
            'Y',
            'D',
            '-',
        );
        $str = preg_replace($search, $replace, $str);
        $str = preg_replace('/(-)+/', '-', $str);
        if ($lowerCase)
            $str = strtolower($str);
        return $str;
    }

    function subStringv($str, $len) {

        //$str = html_entity_decode($str, ENT_QUOTES, $charset='UTF-8');

        if (strlen($str) > $len) {

            $arr = explode(' ', $str);

            $str = substr($str, 0, $len);

            $arrRes = explode(' ', $str);

            $last = $arr[count($arrRes) - 1];

            unset($arr);

            if (strcasecmp($arrRes[count($arrRes) - 1], $last)) {

                unset($arrRes[count($arrRes) - 1]);
            }

            return implode(' ', $arrRes) . "...";
        }

        return $str;
    }

}
