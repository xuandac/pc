<?php

/*
 * *********************************************
 * @author:XuanDacIT <xuandac990@gmail.com>
 * Time:Sep 22, 2017, 9:16:21 AM. 
 * *********************************************
 */

namespace app\services;

use app\models\Categories;
use yii\db\Query;

Class CategoriesService {

    public function get_category_home($where = array(), $OrWhere = array(), $Limit = null, $orderBy = null) {

        $data_categories = Categories::find()
                ->where($where)
                ->orWhere($OrWhere)
                ->andWhere(['Status' => 1])
                ->orderBy($orderBy)
                ->asArray()
                ->all();

        $Array_Categories = array();
        foreach ($data_categories as $key => $value) {
            $ID = $value['ID'];
            $Data_categories = array(
                'ID' => $value['ID'],
                'Title' => $value['Title'],
                'Slug' => $value['Slug'],
                'Description' => $value['Description'],
                'ParentID' => $value['ParentID'],
                'Icon' => $value['Icon'],
                'Sub_categories' => array(),
                'ListPost' => array(),
                'Tin_tieu_diem' => array(),
                'Tin_chuyen_nhuong'=>array(),
            );
            $sub_cat = $this->get_sub_categories($ID);
            array_push($Data_categories['Sub_categories'], $sub_cat['Sub_categories']);

            //----------End get sub-category-----------

            $query = new Query();
            $Data_Post = $query->select([
                        'a.ID',
                        'b.CategoriesId',
                        'c.ID', 'c.Title', 'c.Summary', 'c.Slug', 'c.Thumb',
                    ])->from('categories as a')
                    ->innerJoin('post_categories as b', 'a.ID = b.CategoriesId')
                    ->innerJoin('post as c', 'b.PostId = c.ID')
                    ->limit($Limit)
                    ->orderBy('c.ID DESC')
                    ->where(['a.ID' => $ID, 'c.Status' => 1, 'c.IsDelete' => 0])
                    ->andWhere(['<=', 'c.DatePublic', date('Y-m-d H:i:s')])
                    // ->asArray()            
                    ->all();

            array_push($Data_categories['ListPost'], $Data_Post);

            $Tin_Tieu_Diem = $this->get_post_f($ID, 3, ['c.Focus' => 1]);
            array_push($Data_categories['Tin_tieu_diem'], $Tin_Tieu_Diem);

            //----- Get tin chuyển nhượng
            $Tin_Chuyen_Nhuong = $this->get_post_chuyen_nhuong($sub_cat);
             array_push($Data_categories['Tin_chuyen_nhuong'], $Tin_Chuyen_Nhuong);

            array_push($Array_Categories, $Data_categories);
        }




        return array('data' => $Array_Categories);
    }

    public function get_sub_categories($ParentId) {
        $data_sub = Categories::find()
                        ->where(['Status' => 1, 'ParentID' => $ParentId])
                        ->asArray()->all();
        return array('Sub_categories' => $data_sub);
    }

    public function get_post_categories($Slug) {
        $query = new Query();
        $Data_Post = $query->select([
                    'a.ID',
                    'b.CategoriesId',
                    'c.ID', 'c.Title', 'c.Summary', 'c.Slug', 'c.Thumb', 'c.DateCreate'
                ])->from('categories as a')
                ->innerJoin('post_categories as b', 'a.ID = b.CategoriesId')
                ->innerJoin('post as c', 'b.PostId = c.ID')
                ->orderBy('c.ID DESC')
                ->where(['a.Slug' => $Slug, 'c.Status' => 1, 'c.IsDelete' => 0])
                ->andWhere(['<=', 'c.DatePublic', date('Y-m-d H:i:s')])
                // ->asArray()            
                ->all();
        return array('data' => $Data_Post);
    }

    public function get_post_f($Id_category, $limit = null, $where = array()) {
        $query = new Query();
        $Data_Post = $query->select([
                    'a.ID',
                    'b.CategoriesId',
                    'c.ID', 'c.Title', 'c.Summary', 'c.Slug', 'c.Thumb',
                ])->from('categories as a')
                ->innerJoin('post_categories as b', 'a.ID = b.CategoriesId')
                ->innerJoin('post as c', 'b.PostId = c.ID')
                ->limit($limit)
                ->orderBy('c.ID DESC')
                ->where($where)
                ->andwhere(['a.ID' => $Id_category, 'c.Status' => 1, 'c.IsDelete' => 0])
                ->andWhere(['<=', 'c.DatePublic', date('Y-m-d H:i:s')])
                // ->asArray()            
                ->all();
        return $Data_Post;
    }

    public function get_post_chuyen_nhuong($list_sub_category) {
//        echo '<xmp>';
//        print_r($list_sub_category);
//        echo '</xmp>';

        foreach ($list_sub_category['Sub_categories'] as $key => $value) {
            if (strpos($value['Title'], 'chuyển nhượng') == true) {
                $query = new Query();
                $Data_Post = $query->select([
                            'a.ID',
                            'b.CategoriesId',
                            'c.ID', 'c.Title', 'c.Summary', 'c.Slug', 'c.Thumb',
                        ])->from('categories as a')
                        ->innerJoin('post_categories as b', 'a.ID = b.CategoriesId')
                        ->innerJoin('post as c', 'b.PostId = c.ID')
                        ->limit(3)
                        ->orderBy('c.ID DESC')
                        ->where(['a.ID' => $value['ID'], 'c.Status' => 1, 'c.IsDelete' => 0])
                        ->andWhere(['<=', 'c.DatePublic', date('Y-m-d H:i:s')])
                         //->asArray();            
                        ->all();
                return $Data_Post;
            }
        }
    }

}
