<?php

/* 
 * *********************************************
 * @author:XuanDacIT <xuandac990@gmail.com>
 * Time:Sep 28, 2017, 1:59:10 PM. 
 * *********************************************
 */
namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;


use app\services\PostService;
use app\services\CategoriesService;
class CategoriesPostController extends Controller
{
 public function actionIndex($slug=null,$id)
    {
     
        $Service_Post = new PostService();
        
        $Data_Hot_Cat = $Service_Post->get_post_hot_categories($id);
        $Data_Post_cat = $Service_Post->get_post_categories($id);
//       echo '<xmp>';
//       print_r($Data_Hot_Cat);
//       die;
//        
       
        return $this->render('index',[
            'Data_Hot'=>$Data_Hot_Cat['data'],
            'Data_Post_cat'=>$Data_Post_cat['data'],
            'pagination'=>$Data_Post_cat['pagination']
        ]);
    }
    public function actionViewPost($slug){
         $Service_Post = new PostService();
         $Data_Post = $Service_Post->view_post($slug);
          $id_post = $Data_Post['data']['ID'];
        $Array_Tags = explode(',', $Data_Post['data']['Tags']);
       $Data_Post_Tags = $Service_Post->get_post_tags($id_post, $Array_Tags);
         $Data_Post_Tieu_Diem = $Service_Post->get_post_tieu_diem_lq($id_post, $Array_Tags);
        /* echo '<xmp>';
         print_r($Data_Post);die;*/
        return $this->render('view-post',[
            'Data'=>$Data_Post,
            'Data_Post_Tags'=>$Data_Post_Tags['data'],
            'Data_Post_Tieu_Diem'=>$Data_Post_Tieu_Diem['data']
        ]);
    }

}
