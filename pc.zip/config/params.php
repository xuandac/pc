<?php

return [
    'adminEmail' => 'admin@example.com',
     'site_domain'=>'http://'. $_SERVER['SERVER_NAME'].'/',
    'media'=>'https://cdn.ketquanhanh.vn/bong-da/',
];
